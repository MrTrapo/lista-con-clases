﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace ConsoleApplication1
{
    class Program
    {
       
        static void Main(string[] args)
        {
            Hijo hi = new Hijo();
            string[] indic = { "nombre", "edad", "telefono", "ciudad", "pais", };
            string datos ="";
            string op="";
            int opcion = 0;
            int x = 1;
            string[] nueva = null;
            Console.WriteLine("\n\topciones:\n1. agregar\n2. imprimir de forma alfabetica\n3. eliminar un elemento segun su indice\nopcion:");
            opcion = int.Parse(Console.ReadLine());
            while (x == 1)
            {
                switch (opcion)
                {
                    case 1:
                        while (op != "n")
                        {
                            for (int i = 0; i < 5; i++)
                            {
                                Console.WriteLine("\ningresa" + " " + indic[i] + ":");
                                datos = Console.ReadLine();
                                hi.creahijo(datos, i);
                            }
                            hi.crea_padre(hi.dato);
                            Console.WriteLine("\ndesea agregar otro nodo?\n s/n:");
                            op = Console.ReadLine();
                        }
                        op = "";
                        Console.WriteLine("\n\topciones:\n1. agregar\n2. imprimir de forma alfabetica\n3. eliminar un elemento segun su indice\nopcion:");
                        opcion = int.Parse(Console.ReadLine());
                        break;
                    case 2:
                         nueva=hi.imprime();
                         Console.WriteLine("\n\topciones:\n1. agregar\n2. imprimir de forma alfabetica\n3. eliminar un elemento segun su indice\nopcion:");
                        opcion = int.Parse(Console.ReadLine());
                        break;
                    case 3:
                        if (hi.cola.Count == 0)
                        {
                            Console.WriteLine("\nLa lista  esta  vacia\n");
                            Console.WriteLine("\n\topciones:\n1. agregar\n2. imprimir de forma alfabetica\n3. eliminar un elemento segun su indice\nopcion:");
                            opcion = int.Parse(Console.ReadLine());
                        }
                        else
                        {
                            hi.eliminar(nueva);
                            Console.WriteLine("\n\topciones:\n1. agregar\n2. imprimir de forma alfabetica\n3. eliminar un elemento segun su indice\nopcion:");
                            opcion = int.Parse(Console.ReadLine());
                        }
                        break;
                }
            }
            Console.ReadLine();
          
        }
    }
}
