﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using System.Collections;
namespace ConsoleApplication1
{
    class Nodo
    {
    public Queue cola = new Queue();

    public void crea_padre(string[] dato)
    {
        string info = "";
        for (int i = 0; i < 5; i++)
            info += "  " + dato[i];
        cola.Enqueue(info);
    }
        public string[] imprime()
        {
            IEnumerable pu;
                    
            Console.WriteLine("\n\nexisten " + cola.Count + " elementos padre");
            pu = cola;
            int i = 0;
            string[] cad = new string[cola.Count]; 
            foreach (Object o in pu)
            {
                cad [i++]= o.ToString();
            }
            cad = Ordernar(cad);
            for (int j = 0; j < cola.Count;j++ )
                Console.WriteLine((j+1).ToString()+cad[j]);
            return (cad);
            
        }
        static string[] Ordernar(string[] cadenas)
        {
            return (from c in cadenas orderby c select c).ToArray<string>();
        }

        public void eliminar(string[] nueva)
        {
            int numero = 0;
            Console.WriteLine("indique el elemento con numero que desea eliminar:");
            numero = int.Parse(Console.ReadLine());
            int indic = cola.Count,j=0; 
            nueva[numero-1] = null;
            cola.Clear();
            for (int i = 0; i < indic; i++)
                if (nueva[i] != null)
                {
                    cola.Enqueue(nueva[i]);
                }
                

            

        }

    }
}
