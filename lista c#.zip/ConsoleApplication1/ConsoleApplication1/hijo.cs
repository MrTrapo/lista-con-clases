﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Hijo:Nodo
    {
        public string[] dato = new string[5];
        Nodo nod = new Nodo();
        public void creahijo(string info,int i)
        {      
            dato[i] = info;
        }
        public void envia()
        {
            nod.crea_padre(dato);
        }

    }
}
